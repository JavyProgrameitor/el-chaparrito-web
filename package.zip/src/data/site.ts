export const site = {
  name: "SOC. COOP. EL CHAPARRITO",
  tagline: "Servicios para la agricultura",
  location: "Pueblonuevo del Guadiana (Badajoz)",
  address: "C/ Ronda Poniente, 27 · 06184 · Pueblonuevo del Guadiana · Badajoz",
  phone1: "636483088",
  phone2: "659094474",
  email: "soc.coop.elchaparrito@gmail.com",
  whatsappPhone: "34636483088", // +34 + número (sin espacios)
};
